import display
import random
import time
from PIL import Image, ImageDraw, ImageFont
import os
display = display.Display()
display.switch_mode(1)
img = Image.new('RGB', (240, 240), 'white')
draw = ImageDraw.Draw(img)
prev_x, prev_y = 0, 0
letters = list('abcdefghijklmnopqrstuvwxyz')
letters.extend(letters[:])
letters.extend(letters.copy())
random.shuffle(letters)
Font = ImageFont.truetype(f'lib/Font00.ttf', 24)
had_new_input = False
for letter in letters:
    print(letter)
    img = Image.new('RGB', (240, 240), 'white')
    draw = ImageDraw.Draw(img)
    while True:
        has_new_input = False
        x, y = display.get_input()
        if x != prev_x and y != prev_y and (24 <= x <= 216) and (24 <= y <= 216):
            draw.rectangle((x-2, y-2, x+2, y+2), fill='black', outline=None, width=1)
            if had_new_input:
                draw.line(((prev_x, prev_y), (x,y)), width=3, fill='black')
            has_new_input = True
        elif x!= prev_x and y!= prev_y and x >= 220:
            if input('are you done?'):
                files = os.listdir('/home/pi/Desktop/galah/letters')
                nums = []
                for i in files:
                    if i[0] == letter and '.jpg' in i:
                        nums.append(int(i[1:3]))
                nums.sort()
                if len(nums) == 0:
                    num = 0
                else:
                    num = nums[-1] + 1
                img.save(f'letters/{letter}{num:02d}.jpg')
                img = Image.new('RGB', (240, 240), 'white')
                draw = ImageDraw.Draw(img)
                img.save('in_progress.jpg')
                display.load_image('in_progress.jpg')
                display.write(letter, (60, 0))
                display.update()
                time.sleep(3)
                break
        prev_x, prev_y = x, y
        had_new_input = has_new_input
        img.save('in_progress.jpg')
        display.load_image('in_progress.jpg')
        display.write(letter, (60, 0))
        display.update()
        time.sleep(0.1)
