import tflite_runtime.interpreter as tflite
from PIL import Image
import numpy as np

interpreter = tflite.Interpreter(model_path='vww_96_grayscale_quantized.tflite')
interpreter.allocate_tensors()

input_details = interpreter.get_input_details()
print(input_details)
output_details = interpreter.get_output_details()
print(output_details)

image = Image.open('letters/k00.jpg').resize((96, 96)).split()[0]

input_data = np.expand_dims(np.array(image), axis=0).astype(np.float32)

print(input_data)

interpreter.set_tensor(1, input_data)

interpreter.invoke()

classes = interpreter.get_tensor(output_details[1]['index'])[0]
scores = interpreter.get_tensor(output_details[2]['index'])[0]

print(f'this is a letter {classes[0]} with a certainty of {scores[0]}')